package ahmetcetinkaya.HRMSProjectBackend.core.entities;

public interface Dto {

}

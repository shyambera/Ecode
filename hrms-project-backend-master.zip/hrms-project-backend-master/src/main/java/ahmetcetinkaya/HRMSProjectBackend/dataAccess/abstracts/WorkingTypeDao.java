package ahmetcetinkaya.HRMSProjectBackend.dataAccess.abstracts;

import org.springframework.data.jpa.repository.JpaRepository;

import ahmetcetinkaya.HRMSProjectBackend.entities.concretes.WorkingType;

public interface WorkingTypeDao extends JpaRepository<WorkingType, Short> {
}

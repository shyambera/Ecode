package ahmetcetinkaya.HRMSProjectBackend.business.abstracts;

import ahmetcetinkaya.HRMSProjectBackend.core.business.abstracts.BaseService;
import ahmetcetinkaya.HRMSProjectBackend.entities.concretes.WorkingType;

public interface WorkingTypeService extends BaseService<WorkingType, Short> {
}

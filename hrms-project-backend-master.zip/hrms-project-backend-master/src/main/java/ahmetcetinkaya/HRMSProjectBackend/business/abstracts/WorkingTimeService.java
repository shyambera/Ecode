package ahmetcetinkaya.HRMSProjectBackend.business.abstracts;

import ahmetcetinkaya.HRMSProjectBackend.core.business.abstracts.BaseService;
import ahmetcetinkaya.HRMSProjectBackend.entities.concretes.WorkingTime;

public interface WorkingTimeService extends BaseService<WorkingTime, Short> {
}
